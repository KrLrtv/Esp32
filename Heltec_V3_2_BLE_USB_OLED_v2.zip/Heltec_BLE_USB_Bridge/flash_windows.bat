@echo off
call "%~dp0tools\run_windows.bat" flash
