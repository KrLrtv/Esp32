#include <Arduino.h>
#include <Preferences.h>
#include <NimBLEDevice.h>
#include <USB.h>
#include <USBHID.h>
#include <tusb.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include <esp_system.h>
#include <algorithm>
#include <array>
#include <string>
#include "bridge_config.h"
#include "hid_report_parser.h"
#include "usb_report_descriptor.h"
#if BRIDGE_USE_OLED
#include <U8g2lib.h>
#include "display_model.h"
#include "display_renderer.h"
#endif

// Source prototype, not a USB-HCI Bluetooth adapter.
// UART0: onboard CP2102. Native USB: GPIO19 D- / GPIO20 D+.
using bridge::DecodedReport;
using bridge::ReportMap;
class BridgeUSB final : public USBHIDDevice {
public:
    USBHID hid;
    BridgeUSB() { hid.addDevice(this,sizeof(usbDescriptor)); }
    uint16_t _onGetDescriptor(uint8_t* buffer) override {
        memcpy(buffer,usbDescriptor,sizeof(usbDescriptor));
        return sizeof(usbDescriptor);
    }
};
static BridgeUSB usb;
static Preferences prefs;
static QueueHandle_t inputQueue;
static portMUX_TYPE candidateMux=portMUX_INITIALIZER_UNLOCKED;
static volatile bool queueOverflow=false, connecting=false;
static volatile uint32_t pairingUntil=0, shownPin=0, pinUntil=0;
static const NimBLEUUID uuidHid(uint16_t(0x1812));
static const NimBLEUUID uuidMap(uint16_t(0x2a4b));
static const NimBLEUUID uuidReport(uint16_t(0x2a4d));
static const NimBLEUUID uuidReference(uint16_t(0x2908));
static const NimBLEUUID uuidProtocol(uint16_t(0x2a4e));
static const NimBLEUUID uuidBootKeyboard(uint16_t(0x2a22));
static const NimBLEUUID uuidBootMouse(uint16_t(0x2a33));

enum class Role : uint8_t { Keyboard=0, Mouse=1, Unknown=2 };
enum class Format : uint8_t { Report, BootKeyboard, BootMouse };
struct SavedPeer {
    bool valid=false; char address[18]{}; uint8_t type=0; char name[40]{};
};
static SavedPeer saved[2];
struct InputState {
    uint8_t modifiers=0,buttons=0;
    std::array<uint8_t,32> keys{};
    uint16_t consumer=0;
    bool rollover=false;
};
struct Subscription {
    NimBLERemoteCharacteristic* characteristic=nullptr;
    uint8_t reportId=0;
    Format format=Format::Report;
    InputState state{};
};
struct Slot {
    NimBLEClient* client=nullptr;
    ReportMap map;
    Subscription subscriptions[BRIDGE_MAX_INPUT_REPORTS];
    uint8_t subscriptionCount=0;
    volatile bool up=false,lost=false;
    uint16_t generation=0;
    Role role=Role::Unknown;
    char name[40]{};
};
static Slot slots[2];
struct InputPacket {
    uint8_t slot=0,subscription=0;
    uint16_t generation=0,size=0;
    uint8_t data[ReportMap::MaxReportBytes+1]{};
};
struct Candidate {
    char address[18]{}; uint8_t type=0; char name[40]{};
    int8_t savedIndex=-1; uint16_t appearance=0;
};
static Candidate pending;
static volatile bool candidateReady=false;
struct Backoff { char address[18]{}; uint32_t until=0; };
static Backoff backoff[4];
static uint8_t backoffCursor=0;
static uint32_t nextScan=0;
static int32_t pendingX=0,pendingY=0,pendingWheel=0,pendingPan=0;

static bool before(uint32_t now,uint32_t deadline) { return deadline!=0 && int32_t(deadline-now)>0; }
static bool pairingOpen() { return before(millis(),pairingUntil); }
static bool roleConnected(Role role) {
    for (const Slot& s:slots) if (s.up && s.role==role) return true;
    return false;
}
static void copyText(char* dst,size_t capacity,const char* src) {
    if (capacity) { strncpy(dst,src ? src : "",capacity-1); dst[capacity-1]=0; }
}
static void openPairing() {
    pairingUntil=millis()+BRIDGE_PAIRING_MS;
    Serial.println("PAIR: new-device window opened for 120 seconds.");
}
static void rememberBackoff(const char* address) {
    Backoff& b=backoff[backoffCursor++%4];
    copyText(b.address,sizeof(b.address),address); b.until=millis()+12000;
}
static int savedIndex(const char* address,uint8_t type) {
    for (int i=0;i<2;++i)
        if (saved[i].valid && !strcmp(saved[i].address,address) &&
            (saved[i].type&1)==(type&1)) return i;
    return -1;
}

#if BRIDGE_USE_OLED
static U8G2_SSD1306_128X64_NONAME_F_HW_I2C oled(
    U8G2_R0,BRIDGE_OLED_RESET,BRIDGE_OLED_SCL,BRIDGE_OLED_SDA);
static portMUX_TYPE screenMux=portMUX_INITIALIZER_UNLOCKED;
static bridge::screen::Model screenModel(BRIDGE_DISPLAY_RUSSIAN!=0,BRIDGE_DISPLAY_CLEAR_MS);

// Only copy/update small in-memory objects under this lock. All I2C drawing
// runs in displayTask, outside the BLE-to-USB forwarding path.
static void screenInput(const DecodedReport* event=nullptr) {
    bridge::screen::KeyBits keys{};
    uint8_t modifiers=0,buttons=0; bool rollover=false;
    const bool keyboard=!event || event->keyboard;
    for (const Slot& slot:slots) if (slot.up) {
        for (uint8_t i=0;i<slot.subscriptionCount;++i) {
            const InputState& state=slot.subscriptions[i].state;
            buttons|=state.buttons;
            if (keyboard) {
                modifiers|=state.modifiers; rollover|=state.rollover;
                for (size_t j=0;j<keys.size();++j) keys[j]|=state.keys[j];
            }
        }
    }
    const uint32_t now=millis();
    portENTER_CRITICAL(&screenMux);
    if (keyboard) screenModel.keyboard(keys,modifiers,rollover,now);
    screenModel.mouse(event ? event->x : 0,event ? event->y : 0,
                      event ? event->wheel : 0,event ? event->pan : 0,buttons,now);
    portEXIT_CRITICAL(&screenMux);
}
static void screenStatus() {
    const bool keyboard=roleConnected(Role::Keyboard),mouse=roleConnected(Role::Mouse);
    const bool mounted=tud_mounted();
    portENTER_CRITICAL(&screenMux);
    screenModel.status(keyboard,mouse,mounted);
    portEXIT_CRITICAL(&screenMux);
}
static void screenAction(char action) {
    const uint32_t now=millis();
    portENTER_CRITICAL(&screenMux);
    if (action=='l') screenModel.toggleLanguage(now);
    else if (action=='v') screenModel.togglePrivacy(now);
    else if (action=='c') screenModel.clearWithNotice(now);
    else if (action=='r') screenModel.releaseInputs();
    portEXIT_CRITICAL(&screenMux);
}
static void displayTask(void*) {
    bridge::screen::Frame frame;
    bridge::screen::Animator animation;
    TickType_t wake=xTaskGetTickCount();
    for (;;) {
        const uint32_t now=millis();
        portENTER_CRITICAL(&screenMux);
        const bridge::screen::Snapshot snapshot=screenModel.snapshot(now);
        portEXIT_CRITICAL(&screenMux);
        bridge::screen::Environment env;
        const uint32_t until=pairingUntil,pinDeadline=pinUntil;
        env.pairing=before(now,until);
        env.pairingSeconds=env.pairing ? uint16_t((until-now+999)/1000) : 0;
        env.connecting=connecting; env.pinVisible=before(now,pinDeadline); env.pin=shownPin;
        animation.render(frame,snapshot,env,now);
        oled.clearBuffer();
        oled.drawXBMP(0,0,bridge::screen::Frame::Width,bridge::screen::Frame::Height,frame.pixels);
        oled.sendBuffer();
        vTaskDelayUntil(&wake,pdMS_TO_TICKS(BRIDGE_DISPLAY_FRAME_MS));
    }
}
#else
static void screenInput(const DecodedReport* =nullptr) {}
static void screenStatus() {}
static void screenAction(char) {}
#endif

class ClientCallbacks final : public NimBLEClientCallbacks {
    void onConnect(NimBLEClient*) override { Serial.println("BLE: link established."); }
    void onDisconnect(NimBLEClient* client) override {
        for (Slot& s:slots) if (s.client==client) { s.up=false; s.lost=true; }
        Serial.println("BLE: disconnected; releasing input state.");
    }
    uint32_t onPassKeyRequest() override {
        // The same PIN was configured before secureConnection().
        pinUntil=millis()+90000;
        Serial.printf("PAIR PIN: %06lu; type on keyboard, then Enter.\n",(unsigned long)shownPin);
        return shownPin;
    }
    bool onConfirmPIN(uint32_t pin) override {
        // Display-only IO should not negotiate numeric comparison. Never
        // silently approve an unexpected authentication mode.
        Serial.printf("Unsupported numeric-comparison request: %06lu\n",(unsigned long)pin);
        return false;
    }
};
static ClientCallbacks clientCallbacks;

class AdvertisedCallbacks final : public NimBLEAdvertisedDeviceCallbacks {
    void onResult(NimBLEAdvertisedDevice* device) override {
        if (candidateReady || connecting) return;
        bool free=false; for (const Slot& s:slots) if (!s.up) free=true;
        if (!free) return;
        const std::string address=device->getAddress().toString();
        const uint8_t type=device->getAddress().getType();
        for (const Backoff& b:backoff)
            if (!strcmp(b.address,address.c_str()) && before(millis(),b.until)) return;
        const int known=savedIndex(address.c_str(),type);
        if (known>=0 && roleConnected(Role(known))) return;
        if (known<0) {
            if (!pairingOpen() || !device->isAdvertisingService(uuidHid)) return;
            if (saved[0].valid && saved[1].valid) return;
        }
        const std::string name=device->getName();
        if (BRIDGE_NAME_FILTER[0] && name.find(BRIDGE_NAME_FILTER)==std::string::npos) return;
        Candidate c;
        copyText(c.address,sizeof(c.address),address.c_str());
        copyText(c.name,sizeof(c.name),name.empty() ? "BLE HID" : name.c_str());
        c.type=type; c.savedIndex=int8_t(known);
        c.appearance=device->haveAppearance() ? device->getAppearance() : 0;
        portENTER_CRITICAL(&candidateMux);
        if (!candidateReady) { pending=c; candidateReady=true; }
        portEXIT_CRITICAL(&candidateMux);
        NimBLEDevice::getScan()->stop();
    }
};
static AdvertisedCallbacks advertisedCallbacks;
static void scanFinished(NimBLEScanResults) {}

static void notification(NimBLERemoteCharacteristic* characteristic,
                         uint8_t* data,size_t length,bool) {
    if (!length || length>sizeof(InputPacket::data)) return;
    for (uint8_t i=0;i<2;++i) {
        const Slot& s=slots[i]; if (!s.up) continue;
        for (uint8_t j=0;j<s.subscriptionCount;++j) {
            if (s.subscriptions[j].characteristic!=characteristic) continue;
            InputPacket packet;
            packet.slot=i; packet.subscription=j; packet.generation=s.generation;
            packet.size=uint16_t(length); memcpy(packet.data,data,length);
            if (xQueueSend(inputQueue,&packet,0)!=pdTRUE) queueOverflow=true;
            return;
        }
    }
}
static void clearInput(Slot& s) {
    for (Subscription& sub:s.subscriptions) sub.state=InputState{};
}
static void cleanupSlot(size_t index) {
    Slot& s=slots[index]; s.up=false; clearInput(s);
    NimBLEClient* old=s.client; s.client=nullptr;
    if (old) {
        if (old->isConnected()) old->disconnect();
        NimBLEDevice::deleteClient(old);
    }
    s.subscriptionCount=0;
    for (Subscription& sub:s.subscriptions) sub=Subscription{};
    s.role=Role::Unknown; s.lost=false;
}
static void loadSaved() {
    for (int i=0;i<2;++i) {
        const String address=prefs.getString(i==0 ? "kbd_addr" : "mouse_addr","");
        saved[i].valid=address.length()==17;
        copyText(saved[i].address,sizeof(saved[i].address),address.c_str());
        saved[i].type=prefs.getUChar(i==0 ? "kbd_type" : "mouse_type",0);
        copyText(saved[i].name,sizeof(saved[i].name),
            prefs.getString(i==0 ? "kbd_name" : "mouse_name","").c_str());
    }
}
static NimBLEAddress identityAddress(NimBLEClient* client) {
    ble_gap_conn_desc description{};
    if (ble_gap_conn_find(client->getConnId(),&description)==0)
        return NimBLEAddress(description.peer_id_addr);
    return client->getPeerAddress();
}
static void savePeer(const Slot& s) {
    const int i=int(s.role); if (i>1 || !s.client) return;
    const NimBLEAddress address=identityAddress(s.client);
    saved[i].valid=true; saved[i].type=address.getType();
    copyText(saved[i].address,sizeof(saved[i].address),address.toString().c_str());
    copyText(saved[i].name,sizeof(saved[i].name),s.name);
    prefs.putString(i==0 ? "kbd_addr" : "mouse_addr",saved[i].address);
    prefs.putUChar(i==0 ? "kbd_type" : "mouse_type",saved[i].type);
    prefs.putString(i==0 ? "kbd_name" : "mouse_name",saved[i].name);
}
static bool subscribe(Slot& s,NimBLERemoteCharacteristic* c,uint8_t id,Format format) {
    if (!c || s.subscriptionCount>=BRIDGE_MAX_INPUT_REPORTS) return false;
    if (!c->canNotify() && !c->canIndicate()) return false;
    Subscription& sub=s.subscriptions[s.subscriptionCount];
    sub=Subscription{}; sub.characteristic=c; sub.reportId=id; sub.format=format;
    ++s.subscriptionCount;
    if (!c->subscribe(c->canNotify(),notification)) {
        --s.subscriptionCount; sub=Subscription{}; return false;
    }
    Serial.printf("Subscribed: report ID=%u format=%u\n",id,unsigned(format));
    return true;
}
static bool setupReports(Slot& s,NimBLERemoteService* service,Role preferred) {
    // Discover once before retaining pointers; a later refresh invalidates them.
    auto* characteristics=service->getCharacteristics(true);
    if (!characteristics) return false;
    bool parsed=false;
    if (auto* map=service->getCharacteristic(uuidMap)) {
        const std::string bytes=map->readValue();
        parsed=s.map.parse(reinterpret_cast<const uint8_t*>(bytes.data()),bytes.size());
        if (!parsed) Serial.printf("Report map: %s; trying boot fallback.\n",s.map.error());
    }
    auto* protocol=service->getCharacteristic(uuidProtocol);
    if (protocol && (protocol->canWrite() || protocol->canWriteNoResponse())) {
        uint8_t mode=parsed ? 1 : 0;
        if (!protocol->writeValue(&mode,1,protocol->canWrite()))
            Serial.println("Warning: protocol-mode write failed.");
    }
    if (parsed) {
        if (preferred==Role::Keyboard && s.map.hasKeyboard()) s.role=Role::Keyboard;
        else if (preferred==Role::Mouse && s.map.hasMouse()) s.role=Role::Mouse;
        else s.role=s.map.hasKeyboard() ? Role::Keyboard : s.map.hasMouse() ? Role::Mouse : Role::Unknown;
        for (auto* c:*characteristics) {
            if (!c->getUUID().equals(uuidReport)) continue;
            auto* reference=c->getDescriptor(uuidReference);
            if (!reference) continue; // Do not guess which report this is.
            const std::string ref=reference->readValue();
            if (ref.size()<2 || uint8_t(ref[1])!=1) continue; // Input reports only.
            const uint8_t id=uint8_t(ref[0]);
            if (s.map.reportBytes(id)) subscribe(s,c,id,Format::Report);
        }
        if (s.subscriptionCount) return true;
    }
    // Boot fallback only when protocol mode can actually be set to boot.
    if (!protocol || (!protocol->canWrite() && !protocol->canWriteNoResponse())) return false;
    uint8_t mode=0;
    if (!protocol->writeValue(&mode,1,protocol->canWrite())) return false;
    const bool k=subscribe(s,service->getCharacteristic(uuidBootKeyboard),0,Format::BootKeyboard);
    const bool m=subscribe(s,service->getCharacteristic(uuidBootMouse),0,Format::BootMouse);
    s.role=m ? Role::Mouse : k ? Role::Keyboard : Role::Unknown;
    return k || m;
}
static void connectCandidate(const Candidate& c) {
    int index=-1;
    for (int i=0;i<2;++i) if (!slots[i].up) { index=i; break; }
    if (index<0) return;
    connecting=true; NimBLEDevice::getScan()->stop(); cleanupSlot(index);
    Slot& s=slots[index]; ++s.generation;
    copyText(s.name,sizeof(s.name),c.name);
    s.client=NimBLEDevice::createClient();
    if (!s.client) { connecting=false; return; }
    s.client->setClientCallbacks(&clientCallbacks,false);
    s.client->setConnectTimeout(7);
    s.client->setConnectionParams(6,12,0,400);
    Serial.printf("Connecting %s (%s)\n",c.name,c.address);
    bool success=false;
    do {
        if (!s.client->connect(NimBLEAddress(std::string(c.address),c.type))) {
            Serial.println("Connection failed."); break;
        }
        // Display-only pairing may use this value without calling the client
        // callback. The independent display task keeps the PIN visible while
        // secureConnection() is blocking.
        shownPin=esp_random()%1000000;
        NimBLEDevice::setSecurityPasskey(shownPin); pinUntil=millis()+90000;
        Serial.printf("Pairing PIN, only if requested: %06lu\n",(unsigned long)shownPin);
        if (!s.client->secureConnection()) {
            Serial.println("Pairing/encryption failed: use a free ZMK profile or clear stale bonds.");
            break;
        }
        auto* service=s.client->getService(uuidHid);
        const Role preferred=c.savedIndex>=0 ? Role(c.savedIndex) :
            c.appearance==0x03c1 ? Role::Keyboard : c.appearance==0x03c2 ? Role::Mouse : Role::Unknown;
        if (!service || !setupReports(s,service,preferred) || s.role==Role::Unknown) {
            Serial.println("No supported HID input reports."); break;
        }
        const int role=int(s.role);
        if (roleConnected(s.role)) { Serial.println("Role is already connected."); break; }
        if (saved[role].valid) {
            const NimBLEAddress id=identityAddress(s.client);
            if (strcmp(saved[role].address,id.toString().c_str()) ||
                (saved[role].type&1)!=(id.getType()&1)) {
                Serial.println("Saved role belongs to another peer; clear bonds to replace it.");
                break;
            }
        }
        if (!s.client->isConnected() || s.lost) break;
        savePeer(s); s.up=true;
        Serial.printf("READY: %s, %u input report(s).\n",
            s.role==Role::Keyboard ? "keyboard" : "mouse",s.subscriptionCount);
        success=true;
    } while(false);
    pinUntil=0;
    if (!success) {
        if (c.savedIndex<0 && s.client && s.client->isConnected()) {
            const NimBLEAddress rejected=identityAddress(s.client);
            bool keep=false;
            for (const SavedPeer& p:saved)
                if (p.valid && !strcmp(p.address,rejected.toString().c_str())) keep=true;
            if (!keep) NimBLEDevice::deleteBond(rejected);
        }
        cleanupSlot(index); rememberBackoff(c.address);
    }
    connecting=false; nextScan=millis()+300;
}
static int32_t accumulate(int32_t a,int32_t b) {
    const int64_t v=int64_t(a)+b;
    return int32_t(std::max<int64_t>(-1000000,std::min<int64_t>(1000000,v)));
}
static void consumeInput(const InputPacket& packet) {
    if (packet.slot>=2) return;
    Slot& s=slots[packet.slot];
    if (!s.up || packet.generation!=s.generation || packet.subscription>=s.subscriptionCount) return;
    Subscription& sub=s.subscriptions[packet.subscription];
    DecodedReport d;
    if (sub.format==Format::Report) {
        if (!s.map.decode(sub.reportId,packet.data,packet.size,d)) return;
    } else if (sub.format==Format::BootKeyboard) {
        if (packet.size<8) return;
        d.keyboard=true; d.modifiers=packet.data[0];
        for (int i=2;i<8;++i) {
            const uint8_t k=packet.data[i];
            if (k>=1 && k<=3) d.rollover=true;
            else if (k>=4) d.keys[k>>3] |= uint8_t(1u<<(k&7));
        }
    } else {
        if (packet.size<3) return;
        d.buttonsPresent=true; d.buttons=packet.data[0];
        d.x=int8_t(packet.data[1]); d.y=int8_t(packet.data[2]);
        if (packet.size>=4) d.wheel=int8_t(packet.data[3]);
    }
    if (d.keyboard) {
        sub.state.keys=d.keys; sub.state.modifiers=d.modifiers; sub.state.rollover=d.rollover;
    }
    if (d.buttonsPresent) sub.state.buttons=d.buttons;
    if (d.consumerPresent) sub.state.consumer=d.consumer;
    pendingX=accumulate(pendingX,d.x); pendingY=accumulate(pendingY,d.y);
    pendingWheel=accumulate(pendingWheel,d.wheel); pendingPan=accumulate(pendingPan,d.pan);
    screenInput(&d);
}
static bool sendUSB() {
    static bool wasMounted=false,keyboardSent=false,mouseSent=false,consumerSent=false;
    static uint8_t lastKeyboard[8]{}; static uint8_t lastButtons=0;
    static uint16_t lastConsumer=0;
    const bool mounted=tud_mounted();
    if (mounted!=wasMounted) {
        keyboardSent=mouseSent=consumerSent=false; wasMounted=mounted;
    }
    if (!mounted) { pendingX=pendingY=pendingWheel=pendingPan=0; return true; }
    if (!tud_hid_ready()) return false;
    uint8_t keyboard[8]{},buttons=0; uint16_t consumer=0;
    std::array<uint8_t,32> keys{}; bool rollover=false;
    for (const Slot& s:slots) if (s.up) for (uint8_t j=0;j<s.subscriptionCount;++j) {
        const InputState& v=s.subscriptions[j].state;
        keyboard[0] |= v.modifiers; buttons |= v.buttons;
        for (size_t k=0;k<keys.size();++k) keys[k] |= v.keys[k];
        rollover |= v.rollover;
        if (!consumer && v.consumer) consumer=v.consumer;
    }
    size_t count=0;
    for (unsigned k=4;k<256;++k) {
        if (k>=0xe0 && k<=0xe7) continue;
        if (!(keys[k>>3] & (1u<<(k&7)))) continue;
        if (count<6) keyboard[2+count]=uint8_t(k);
        ++count;
    }
    if (rollover || count>6) memset(keyboard+2,1,6);
    if (!keyboardSent || memcmp(lastKeyboard,keyboard,8)) {
        if (usb.hid.SendReport(1,keyboard,8)) {
            memcpy(lastKeyboard,keyboard,8); keyboardSent=true;
        }
        return false;
    }
    if (!consumerSent || consumer!=lastConsumer) {
        const uint8_t bytes[2]={uint8_t(consumer),uint8_t(consumer>>8)};
        if (usb.hid.SendReport(3,bytes,2)) { lastConsumer=consumer; consumerSent=true; }
        return false;
    }
    if (!mouseSent || buttons!=lastButtons || pendingX || pendingY || pendingWheel || pendingPan) {
        const int16_t x=int16_t(std::max<int32_t>(-32767,std::min<int32_t>(32767,pendingX)));
        const int16_t y=int16_t(std::max<int32_t>(-32767,std::min<int32_t>(32767,pendingY)));
        const int8_t wheel=int8_t(std::max<int32_t>(-127,std::min<int32_t>(127,pendingWheel)));
        const int8_t pan=int8_t(std::max<int32_t>(-127,std::min<int32_t>(127,pendingPan)));
        const uint8_t bytes[7]={buttons,uint8_t(x),uint8_t(uint16_t(x)>>8),
            uint8_t(y),uint8_t(uint16_t(y)>>8),uint8_t(wheel),uint8_t(pan)};
        if (usb.hid.SendReport(2,bytes,sizeof(bytes))) {
            lastButtons=buttons; mouseSent=true;
            pendingX-=x; pendingY-=y; pendingWheel-=wheel; pendingPan-=pan;
        }
        return false;
    }
    return true;
}
static void clearBonds() {
    Serial.println("CLEAR: deleting BOTH saved peers and all receiver BLE bonds.");
    NimBLEDevice::getScan()->stop();
    portENTER_CRITICAL(&candidateMux); candidateReady=false; portEXIT_CRITICAL(&candidateMux);
    for (int i=0;i<2;++i) cleanupSlot(i);
    NimBLEDevice::deleteAllBonds(); prefs.clear();
    for (SavedPeer& p:saved) p=SavedPeer{};
    xQueueReset(inputQueue); pendingX=pendingY=pendingWheel=pendingPan=0;
    screenAction('r'); screenAction('c');
    pinUntil=0; openPairing(); nextScan=millis()+1000;
}
static void buttonsAndSerial() {
    // Debounced multi-click handling on a RUNNING board:
    // 1x pair, 2x screen RU/EN, 3x privacy. 5 s still clears both bonds.
    static bool rawLast=false,down=false,cleared=false;
    static uint32_t changedAt=0,pressedAt=0,releasedAt=0;
    static uint8_t clicks=0;
    const uint32_t now=millis();
    const bool raw=digitalRead(BRIDGE_BUTTON_PIN)==LOW;
    if (raw!=rawLast) { rawLast=raw; changedAt=now; }
    if (raw!=down && uint32_t(now-changedAt)>=25) {
        down=raw;
        if (down) { pressedAt=now; cleared=false; }
        else if (!cleared && uint32_t(now-pressedAt)>=35) {
            if (uint32_t(now-pressedAt)>800) clicks=0; // not a tap
            else { if (clicks<3) ++clicks; releasedAt=now; }
        }
    }
    if (down && !cleared && uint32_t(now-pressedAt)>=5000) {
        cleared=true; clicks=0; clearBonds();
    }
    if (!raw && !down && clicks && uint32_t(now-releasedAt)>=BRIDGE_DISPLAY_CLICK_GAP_MS) {
        if (clicks==1) openPairing();
        else if (clicks==2) screenAction('l');
        else screenAction('v');
        clicks=0;
    }
    while (Serial.available()) {
        const char c=char(Serial.read());
        if (c=='p') openPairing();
        else if (c=='X') clearBonds();
        else if (c=='l' || c=='v' || c=='c') screenAction(c);
        else if (c=='s') Serial.printf("KBD=%d MOUSE=%d pairing=%d\n",
            roleConnected(Role::Keyboard),roleConnected(Role::Mouse),pairingOpen());
    }
}

void setup() {
    Serial.begin(115200); delay(250);
    Serial.println("\nHeltec BLE -> USB HID bridge / OLED DASHBOARD v2 / SOURCE PROTOTYPE");
    pinMode(BRIDGE_BUTTON_PIN,INPUT_PULLUP);
    inputQueue=xQueueCreate(64,sizeof(InputPacket));
    if (!inputQueue) { Serial.println("Fatal: queue allocation failed."); for (;;) delay(1000); }
#if BRIDGE_USE_OLED
    pinMode(BRIDGE_VEXT_PIN,OUTPUT); digitalWrite(BRIDGE_VEXT_PIN,LOW);
    delay(50); oled.setBusClock(400000); oled.begin();
    if (xTaskCreate(displayTask,"bridge-display",6144,nullptr,1,nullptr)!=pdPASS)
        Serial.println("Warning: OLED task could not start; input bridge remains available.");
#endif
    USB.productName("Heltec BLE HID Bridge");
    USB.manufacturerName("DIY bridge prototype");
    usb.hid.begin(); USB.begin();
    prefs.begin("ble-usb-bridge",false); loadSaved();
    NimBLEDevice::init("Heltec HID receiver");
    NimBLEDevice::setMTU(185);
    NimBLEDevice::setSecurityAuth(true,false,true); // Bonding + SC; Just Works allowed.
    NimBLEDevice::setSecurityIOCap(BLE_HS_IO_DISPLAY_ONLY);
    NimBLEScan* scan=NimBLEDevice::getScan();
    scan->setAdvertisedDeviceCallbacks(&advertisedCallbacks,true);
    scan->setActiveScan(true); scan->setInterval(80); scan->setWindow(30);
    if (!saved[0].valid || !saved[1].valid) openPairing();
    Serial.println("UART: p=pair; s=status; X=clear ALL bonds; l=screen RU/EN; v=privacy; c=clear text.");
}
void loop() {
    buttonsAndSerial();
    bool inputReleased=false;
    for (size_t i=0;i<2;++i) if (slots[i].lost) { cleanupSlot(i); inputReleased=true; }
    if (inputReleased) screenInput();
    static uint32_t lastScreenStatus=0;
    if (uint32_t(millis()-lastScreenStatus)>=50) { screenStatus(); lastScreenStatus=millis(); }
    if (queueOverflow) {
        queueOverflow=false; xQueueReset(inputQueue);
        for (Slot& s:slots) clearInput(s);
        pendingX=pendingY=pendingWheel=pendingPan=0;
        screenAction('r');
        Serial.println("Input overflow: released all keys/buttons.");
    }
    // Preserve press/release transitions: flush an input state before consuming
    // the next BLE notification. Do not collapse a batch to its last state.
    InputPacket packet;
    if (sendUSB() && xQueueReceive(inputQueue,&packet,0)==pdTRUE) {
        consumeInput(packet); sendUSB();
    }
    Candidate candidate; bool have=false;
    portENTER_CRITICAL(&candidateMux);
    if (candidateReady) { candidate=pending; candidateReady=false; have=true; }
    portEXIT_CRITICAL(&candidateMux);
    if (have) connectCandidate(candidate);
    else if (!before(millis(),nextScan)) {
        bool free=false; for (const Slot& s:slots) if (!s.up) free=true;
        NimBLEScan* scan=NimBLEDevice::getScan();
        if (free && !scan->isScanning()) {
            scan->clearResults();
            if (!scan->start(3,scanFinished,false)) nextScan=millis()+1000;
        }
    }
    delay(1);
}
