# OLED Dashboard v2

- Added a separate RAM-only keyboard-display model with US/Russian maps.
- Added a self-contained Latin/Cyrillic 5x7 bitmap font.
- Added a shared 128x64 renderer for firmware and host preview.
- Added mouse sway, cursor trail, click ripples/button flashes and scroll arrows.
- Retained an independent pairing-PIN screen.
- Added BOOT double-click language and triple-click privacy; retained single-click
  pairing and 5-second bond reset. Single-click now waits for multi-click timeout.
- Added UART l/v/c for screen-only actions.
- Added 30-second text expiration and explicit hidden mode.
- Added a short-lock snapshot between input and display tasks; no I2C in input path.
- Increased display-task stack to 6144 bytes; target frame interval 40 ms.
- Kept BLE/USB dependencies, USB descriptor, pairing storage and flash layout.
- Added host tests and a synthetic-input preview. No compiled firmware included.
