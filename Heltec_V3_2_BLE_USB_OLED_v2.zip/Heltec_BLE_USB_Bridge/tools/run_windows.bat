@echo off
setlocal
cd /d "%~dp0.."
set PYTHONUTF8=1
where py >nul 2>nul
if not errorlevel 1 goto use_py
where python >nul 2>nul
if not errorlevel 1 goto use_python
echo Python was not found. Install Python 3.11 or 3.12 and enable Add to PATH.
set RC=1
goto finish
:use_py
py -3 tools\windows.py %1
set RC=%ERRORLEVEL%
goto finish
:use_python
python tools\windows.py %1
set RC=%ERRORLEVEL%
:finish
if not "%RC%"=="0" echo ERROR: the operation did not complete. Read the message above.
echo.
pause
exit /b %RC%
