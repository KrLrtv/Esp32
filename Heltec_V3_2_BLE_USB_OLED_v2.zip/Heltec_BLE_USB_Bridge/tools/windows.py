"""Build/flash helper: downloads pinned tools on the user's computer.
No administrator privileges are requested; no automatic full flash erase.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / ".tools" / "venv"
PYTHON = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
CORE = ROOT / ".tools" / "platformio"
ENV = dict(os.environ, PLATFORMIO_CORE_DIR=str(CORE), PYTHONUTF8="1")
PINNED = {"platformio": "6.1.16", "esptool": "4.8.1"}


def run(args: list[str]) -> subprocess.CompletedProcess:
    print("\n> " + subprocess.list2cmdline([str(x) for x in args]), flush=True)
    return subprocess.run([str(x) for x in args], cwd=ROOT, env=ENV, check=True)


def bootstrap() -> None:
    if sys.version_info < (3, 10):
        raise RuntimeError("Install Python 3.11 or 3.12 and run again.")
    if not PYTHON.exists():
        run([sys.executable, "-m", "venv", str(VENV)])
    marker = VENV / "bridge-tools.json"
    try:
        installed = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        installed = None
    if installed != PINNED:
        run([str(PYTHON), "-m", "pip", "install", *[f"{k}=={v}" for k, v in PINNED.items()]])
        marker.write_text(json.dumps(PINNED), encoding="utf-8")


def pio(*args: str) -> None:
    run([str(PYTHON), "-m", "platformio", *args])


def choose_port() -> str:
    pio("device", "list")
    while True:
        port = input("Onboard CP2102 port (for example COM3): ").strip()
        if (os.name == "nt" and re.fullmatch(r"COM[1-9][0-9]*", port, re.I)) or (
            os.name != "nt" and port.startswith("/dev/")
        ):
            return port.upper() if os.name == "nt" else port
        print("Choose your Heltec CP2102 port from the list, not another device.")


def export_binaries() -> None:
    build = ROOT / ".pio" / "build" / "heltec_v3"
    framework = CORE / "packages" / "framework-arduinoespressif32"
    parts = [
        ("0x0", build / "bootloader.bin"),
        ("0x8000", build / "partitions.bin"),
        ("0xe000", framework / "tools" / "partitions" / "boot_app0.bin"),
        ("0x10000", build / "firmware.bin"),
    ]
    for _, path in parts:
        if not path.is_file():
            raise RuntimeError(f"Expected build output is missing: {path}")
    output = ROOT / "output"
    output.mkdir(exist_ok=True)
    for _, path in parts:
        shutil.copy2(path, output / path.name)
    command = [str(PYTHON), "-m", "esptool", "--chip", "esp32s3", "merge_bin",
               "-o", str(output / "heltec_bridge_full.bin"), "--flash_mode", "dio",
               "--flash_freq", "80m", "--flash_size", "8MB"]
    for address, path in parts:
        command.extend([address, str(path)])
    run(command)
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in output.glob("*.bin")}
    (output / "SHA256.json").write_text(json.dumps(hashes, indent=2), encoding="utf-8")
    (output / "FLASH_OFFSETS.txt").write_text(
        "heltec_bridge_full.bin: flash at 0x0 for INITIAL installation.\n"
        "WARNING: flashing the merged image replaces NVS and removes saved BLE bonds.\n"
        "Separate images: bootloader.bin 0x0; partitions.bin 0x8000; "
        "boot_app0.bin 0xe000; firmware.bin 0x10000.\n"
        "Never flash application-only firmware.bin at 0x0.\n", encoding="utf-8")
    print(f"\nBuilt files: {output}")


def main() -> int:
    mode = sys.argv[1] if len(sys.argv) > 1 else "build"
    if mode not in {"build", "flash", "monitor"}:
        raise RuntimeError("Usage: windows.py build|flash|monitor")
    bootstrap()
    if mode == "build":
        pio("run", "-e", "heltec_v3")
        export_binaries()
    elif mode == "flash":
        print("Connect ONLY onboard USB-C for flashing. Disconnect battery and extra USB.")
        port = choose_port()
        pio("run", "-e", "heltec_v3", "--target", "upload", "--upload-port", port)
        # Upload has already succeeded at this point, even if an optional
        # merged-image export fails afterwards.
        print("UPLOAD COMPLETE. Disconnect onboard USB-C before using powered native USB.")
        export_binaries()
    else:
        port = choose_port()
        print("Ctrl+C exits. Never connect the +5V supplies of two USB cables together.")
        pio("device", "monitor", "--port", port, "--baud", "115200")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nCancelled.")
        raise SystemExit(130)
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"\nERROR: {error}\nKeep the complete error text for troubleshooting.", file=sys.stderr)
        raise SystemExit(1)
