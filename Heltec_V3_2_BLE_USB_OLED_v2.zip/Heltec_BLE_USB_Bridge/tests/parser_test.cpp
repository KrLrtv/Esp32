#include "hid_report_parser.h"
#include "usb_report_descriptor.h"
#include <assert.h>
#include <stdio.h>
using bridge::ReportMap;
using bridge::DecodedReport;
static void setBits(uint8_t* p,unsigned offset,unsigned width,uint32_t v) {
    for (unsigned i=0;i<width;++i)
        if (v & (uint32_t(1)<<i)) p[(offset+i)/8] |= uint8_t(1u<<((offset+i)%8));
}
int main() {
    ReportMap map; DecodedReport d;
    const uint8_t keyboard[]={
        0x05,1,0x09,6,0xa1,1,0x05,7,0x19,0xe0,0x29,0xe7,
        0x15,0,0x25,1,0x75,1,0x95,8,0x81,2,
        0x75,8,0x95,1,0x81,1,
        0x19,0,0x29,0x65,0x15,0,0x25,0x65,0x75,8,0x95,6,0x81,0,0xc0};
    assert(map.parse(keyboard,sizeof(keyboard)));
    assert(map.hasKeyboard() && !map.hasMouse() && map.reportBytes(0)==8);
    uint8_t k[8]={2,0,4,5,0,0,0,0};
    assert(map.decode(0,k,8,d));
    assert(d.keyboard && d.modifiers==2 && d.keys[0]==0x30 && !d.rollover);
    k[2]=1; assert(map.decode(0,k,8,d) && d.rollover);
    assert(!map.decode(0,k,7,d)); assert(!map.decode(33,k,8,d));
    const uint8_t nkro[]={
        0x05,1,0x09,6,0xa1,1,0x85,4,
        0x05,7,0x19,0xe0,0x29,0xe7,0x15,0,0x25,1,0x75,1,0x95,8,0x81,2,
        0x19,0,0x29,0x7f,0x75,1,0x95,0x80,0x81,2,0xc0};
    assert(map.parse(nkro,sizeof(nkro)) && map.reportBytes(4)==17);
    uint8_t nk[17]{}; nk[0]=0x40; setBits(nk,12,1,1); setBits(nk,128,1,1);
    assert(map.decode(4,nk,17,d));
    assert(d.modifiers==0x40 && d.keys[0]==0x10 && d.keys[15]==1);
    const uint8_t mouse[]={
        0x05,1,0x09,2,0xa1,1,0x85,2,
        0x05,9,0x19,1,0x29,5,0x15,0,0x25,1,0x75,1,0x95,5,0x81,2,
        0x75,3,0x95,1,0x81,1,
        0x05,1,0x09,0x30,0x09,0x31,0x16,0,0xf8,0x26,0xff,7,
        0x75,12,0x95,2,0x81,6,
        0x09,0x38,0x15,0x81,0x25,0x7f,0x75,8,0x95,1,0x81,6,0xc0};
    assert(map.parse(mouse,sizeof(mouse)) && map.hasMouse() && map.reportBytes(2)==5);
    uint8_t m[5]{}; m[0]=0x11;
    setBits(m,8,12,uint32_t(-123)); setBits(m,20,12,234); setBits(m,32,8,uint32_t(-3));
    assert(map.decode(2,m,5,d));
    assert(d.buttons==0x11 && d.x==-123 && d.y==234 && d.wheel==-3);
    uint8_t prefixed[6]={2}; memcpy(prefixed+1,m,5);
    assert(map.decode(2,prefixed,6,d) && d.x==-123);
    const uint8_t consumer[]={0x05,0x0c,0x09,1,0xa1,1,0x85,3,
        0x19,0,0x2a,0xff,3,0x15,0,0x26,0xff,3,0x75,16,0x95,1,0x81,0,0xc0};
    assert(map.parse(consumer,sizeof(consumer)));
    uint8_t c[]={0xe9,0};
    assert(map.decode(3,c,2,d) && d.consumerPresent && d.consumer==0xe9);
    c[0]=0; assert(map.decode(3,c,2,d) && d.consumerPresent && !d.consumer);
    const uint8_t truncated[]={0x05}; assert(!map.parse(truncated,sizeof(truncated)));
    const uint8_t invalidId[]={0x85,0}; assert(!map.parse(invalidId,sizeof(invalidId)));
    const uint8_t pop[]={0xb4}; assert(!map.parse(pop,sizeof(pop)));
    assert(map.parse(usbDescriptor,sizeof(usbDescriptor)));
    assert(map.hasKeyboard() && map.hasMouse() && map.reportCount()==3);
    assert(map.reportBytes(1)==8 && map.reportBytes(2)==7 && map.reportBytes(3)==2);
    uint8_t usbMouse[]={0x81,0x01,0x80,0xff,0x7f,0xff,0x02};
    assert(map.decode(2,usbMouse,7,d));
    assert(d.buttons==0x81 && d.x==-32767 && d.y==32767 && d.wheel==-1 && d.pan==2);
    puts("PASS: boot keyboard, NKRO, modifiers, rollover, 12-bit mouse, wheel,");
    puts("report IDs, optional prefixed ID, media release, malformed-map guards,");
    puts("and the project's USB descriptor/report sizes (host-only tests).");
}
