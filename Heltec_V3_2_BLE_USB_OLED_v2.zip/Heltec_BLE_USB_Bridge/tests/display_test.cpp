#include <assert.h>
#include <stdint.h>
#include <iostream>
#include "display_model.h"
#include "display_renderer.h"
using namespace bridge::screen;
static KeyBits keys(std::initializer_list<uint8_t> list) {
    KeyBits b{}; for (uint8_t k:list) b[k>>3]|=uint8_t(1u<<(k&7)); return b;
}
static void tap(Model& m,uint8_t key,uint8_t mods,uint32_t now) {
    m.keyboard(keys({key}),mods,false,now);
    m.keyboard(keys({}),0,false,now+1);
}
int main() {
    Model m(false,30000);
    tap(m,4,0,100); tap(m,5,2,200); tap(m,6,0,300);
    auto s=m.snapshot(301); assert(s.length==3 && s.text[0]=='a' && s.text[1]=='B' && s.text[2]=='c');
    tap(m,42,0,400); s=m.snapshot(401); assert(s.length==2 && s.text[1]=='B');
    tap(m,6,1,500); tap(m,4,4,600); tap(m,9,8,700); // Ctrl/Alt/GUI must not append.
    assert(m.snapshot(701).length==2);
    m.keyboard(keys({4}),0,false,800); m.keyboard(keys({4}),2,false,810);
    assert(m.snapshot(811).length==3); // modifier change does not duplicate a held key.
    m.keyboard(keys({}),0,false,820);
    tap(m,57,0,830); tap(m,5,0,840); tap(m,6,2,850);
    s=m.snapshot(851); assert(s.text[3]=='B' && s.text[4]=='c' && s.caps);
    m.toggleLanguage(900); tap(m,57,0,901); tap(m,4,0,910); tap(m,47,2,920); tap(m,53,0,930);
    s=m.snapshot(931); assert(s.russian && s.text[s.length-3]==0x444 && s.text[s.length-2]==0x425 && s.text[s.length-1]==0x451);
    assert(character(32,true,false,true,true)==0x2116);
    tap(m,40,0,940); tap(m,43,0,950);
    s=m.snapshot(951); assert(s.text[s.length-2]==0x21B5 && s.text[s.length-1]==0x21E5);
    m.togglePrivacy(1000); tap(m,4,0,1010);
    s=m.snapshot(1011); assert(s.hidden && s.length==0);
    for (auto c:s.text) assert(c==0);
    m.togglePrivacy(1020); tap(m,4,0,1030); assert(m.snapshot(1031).length==1);
    assert(m.snapshot(31031).length==0); // inactivity clear, independent of mouse motion.
    m.mouse(100,200,1,-1,1,32000); m.mouse(-20,-50,2,0,0,32010);
    s=m.snapshot(32020); assert(s.dx==80 && s.dy==150 && s.wheel==3 && s.pan==-1 && s.buttons==0 && s.clicks==1);
    s=m.snapshot(32021); assert(s.dx==0 && s.dy==0 && s.clicks==0);
    m.mouse(INT32_MAX,INT32_MIN,INT32_MAX,INT32_MIN,0,32030);
    s=m.snapshot(32031); assert(s.dx==1000000 && s.dy==-1000000);
    for (uint32_t t=40000;t<40200;t+=2) tap(m,4,0,t);
    s=m.snapshot(40200); assert(s.length==TextCapacity);
    for (unsigned i=0;i<60;++i) tap(m,42,0,41000+i*2);
    assert(m.snapshot(42000).length==0);
    m.keyboard(keys({4}),0,false,43000); m.keyboard(keys({}),0,true,43010);
    m.keyboard(keys({4}),0,false,43020); assert(m.snapshot(43021).length==1);
    // Timer wrap-around, release reset, rollover and all mapping/renderer bounds.
    Model wrap(false,50); tap(wrap,4,0,UINT32_MAX-20); assert(wrap.snapshot(20).length==1);
    assert(wrap.snapshot(40).length==0);
    m.releaseInputs(); tap(m,5,0,44000); assert(m.snapshot(44001).length==2);
    for (unsigned layout=0;layout<2;++layout) for (unsigned shift=0;shift<2;++shift)
        for (unsigned caps=0;caps<2;++caps) for (unsigned k=0;k<256;++k) {
            const uint16_t cp=character(uint8_t(k),shift,caps,layout,true);
            if (!cp) continue;
            bool found=false; for (const Glyph& g:Font) if (g.code==cp) found=true;
            assert(found);
        }
    Frame frame; Animator animation; Environment env;
    for (uint32_t t=0;t<20000;t+=40) {
        m.status(true,true,true);
        m.mouse(t&1 ? -1000000 : 1000000,t&2 ? -1000000 : 1000000,1,-1,uint8_t(t%256),50000+t);
        s=m.snapshot(50000+t);
        env.pinVisible=t<300; env.pin=123456;
        env.pairing=t<1000; env.pairingSeconds=120;
        animation.render(frame,s,env,50000+t);
        bool any=false; for (uint8_t b:frame.pixels) any|=b!=0; assert(any);
    }
    frame.clear(); frame.box(-100,-100,120,120); assert(frame.at(0,0));
    frame.pixel(-1,-1); frame.pixel(128,64); assert(!frame.at(128,64));
    std::cout << "PASS: screen text/layout/modifiers/privacy/timeout/ring buffer/mouse accumulation/font coverage/frame bounds.\n";
}
