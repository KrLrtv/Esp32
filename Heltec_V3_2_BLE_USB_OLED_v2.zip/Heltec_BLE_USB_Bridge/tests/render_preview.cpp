#include <fstream>
#include <cstdlib>
#include <iostream>
#include <string>
#include "display_model.h"
#include "display_renderer.h"
using namespace bridge::screen;
static void tap(Model& model,uint8_t key,uint8_t mod,uint32_t now) {
    KeyBits b{}; b[key>>3]|=uint8_t(1u<<(key&7));
    model.keyboard(b,mod,false,now); model.keyboard(KeyBits{},0,false,now+1);
}
static void save(const Frame& frame,const std::string& path) {
    std::ofstream out(path,std::ios::binary);
    if (!out) { std::cerr<<"Cannot write "<<path<<"\n"; std::exit(1); }
    out<<"P5\n128 64\n255\n";
    for (int y=0;y<64;++y) for (int x=0;x<128;++x) {
        const uint8_t p=frame.at(x,y) ? 255 : 0;
        out.write(reinterpret_cast<const char*>(&p),1);
    }
}
int main(int argc,char** argv) {
    if (argc!=2) { std::cerr<<"Usage: render_preview OUTPUT_DIRECTORY\n"; return 1; }
    Model model(false,30000); model.status(true,true,true);
    Animator animation; Frame frame; Environment env;
    const uint8_t hello[]={11,8,15,15,18,44,26,18,21,15,7,30}; // Hello world!
    for (unsigned i=0;i<220;++i) {
        const uint32_t now=1000+i*40;
        if (i>=4 && i<52 && (i-4)%4==0) {
            const unsigned k=(i-4)/4;
            tap(model,hello[k],k==0 || k==11 ? 2 : 0,now);
        }
        if (i==94) { model.clearText(); model.toggleLanguage(now); }
        // "Привет, Кирилл!" with physical keys in RU layout.
        const uint8_t ru[]={10,11,5,7,23,17,56,44,21,5,11,5,14,14,30};
        if (i>=131 && i<191 && (i-131)%4==0) {
            const unsigned k=(i-131)/4;
            const bool shifted=k==0 || k==6 || k==8 || k==14;
            tap(model,ru[k],shifted ? 2 : 0,now);
        }
        const int phase=int(i%80);
        const int dx=phase<20 ? 15 : phase<40 ? -6 : phase<60 ? -15 : 6;
        const int dy=phase<20 ? -2 : phase<40 ? 3 : phase<60 ? 2 : -3;
        uint8_t buttons=0;
        if (i%80>=22 && i%80<27) buttons=1;
        if (i%80>=42 && i%80<47) buttons=2;
        if (i%80>=62 && i%80<66) buttons=4;
        const int wheel=i%80>=70 && i%80<=76 ? (i%160>=80 ? -1 : 1) : 0;
        model.mouse(dx,dy,wheel,0,buttons,now);
        animation.render(frame,model.snapshot(now),env,now);
        char file[32]; snprintf(file,sizeof(file),"/frame_%03u.pgm",i);
        save(frame,std::string(argv[1])+file);
    }
    env.pinVisible=true; env.pin=123456;
    animation.render(frame,model.snapshot(11000),env,11000);
    save(frame,std::string(argv[1])+"/pin.pgm");
    std::cout<<"Rendered 220 synthetic-input frames with the production renderer.\n";
}
