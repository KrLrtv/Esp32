#pragma once
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "display_model.h"
#include "display_font.h"

namespace bridge { namespace screen {
inline int clampInt(int v,int lo,int hi) { return v<lo ? lo : v>hi ? hi : v; }
// 128x64 monochrome XBM: row-major, least-significant bit first.
// Exactly the same renderer is used by the board and the host preview.
class Frame {
public:
    static constexpr int Width=128,Height=64;
    uint8_t pixels[Width*Height/8]{};
    void clear() { memset(pixels,0,sizeof(pixels)); }
    void pixel(int x,int y,bool on=true) {
        if (x<0 || x>=Width || y<0 || y>=Height) return;
        uint8_t& b=pixels[y*(Width/8)+(x>>3)];
        if (on) b|=uint8_t(1u<<(x&7)); else b&=uint8_t(~(1u<<(x&7)));
    }
    bool at(int x,int y) const {
        return x>=0 && x<Width && y>=0 && y<Height &&
               (pixels[y*(Width/8)+(x>>3)] & (1u<<(x&7)));
    }
    void line(int x0,int y0,int x1,int y1,bool on=true) {
        int dx=x1>x0 ? x1-x0 : x0-x1,sx=x0<x1 ? 1 : -1;
        int dy=y1>y0 ? y0-y1 : y1-y0,sy=y0<y1 ? 1 : -1;
        int error=dx+dy;
        for (;;) {
            pixel(x0,y0,on); if (x0==x1 && y0==y1) break;
            const int twice=error*2;
            if (twice>=dy) { error+=dy; x0+=sx; }
            if (twice<=dx) { error+=dx; y0+=sy; }
        }
    }
    void box(int x,int y,int w,int h,bool on=true) {
        const int endX=clampInt(x+w,0,Width),endY=clampInt(y+h,0,Height);
        for (int yy=clampInt(y,0,Height);yy<endY;++yy)
            for (int xx=clampInt(x,0,Width);xx<endX;++xx) pixel(xx,yy,on);
    }
    void rect(int x,int y,int w,int h,bool on=true) {
        line(x,y,x+w-1,y,on); line(x,y+h-1,x+w-1,y+h-1,on);
        line(x,y,x,y+h-1,on); line(x+w-1,y,x+w-1,y+h-1,on);
    }
    void roundRect(int x,int y,int w,int h,bool fill=false,bool on=true) {
        if (w<5 || h<5) { if (fill) box(x,y,w,h,on); else rect(x,y,w,h,on); return; }
        if (fill) { box(x+2,y,w-4,h,on); box(x,y+2,w,h-4,on); box(x+1,y+1,w-2,h-2,on); }
        else {
            line(x+2,y,x+w-3,y,on); line(x+2,y+h-1,x+w-3,y+h-1,on);
            line(x,y+2,x,y+h-3,on); line(x+w-1,y+2,x+w-1,y+h-3,on);
            pixel(x+1,y+1,on); pixel(x+w-2,y+1,on);
            pixel(x+1,y+h-2,on); pixel(x+w-2,y+h-2,on);
        }
    }
    void circle(int cx,int cy,int radius,bool on=true) {
        int x=radius,y=0,error=1-radius;
        while (x>=y) {
            pixel(cx+x,cy+y,on); pixel(cx+y,cy+x,on); pixel(cx-y,cy+x,on); pixel(cx-x,cy+y,on);
            pixel(cx-x,cy-y,on); pixel(cx-y,cy-x,on); pixel(cx+y,cy-x,on); pixel(cx+x,cy-y,on);
            ++y;
            if (error<0) error+=2*y+1; else { --x; error+=2*(y-x)+1; }
        }
    }
    void glyph(int x,int y,uint16_t code,int scale=1) {
        const uint8_t* rows=glyphRows(code);
        for (int r=0;r<7;++r) for (int c=0;c<5;++c)
            if (rows[r] & (1u<<(4-c))) box(x+c*scale,y+r*scale,scale,scale);
    }
    void text(int x,int y,const char* s,int scale=1) {
        for (;*s;++s,x+=6*scale) glyph(x,y,uint8_t(*s),scale);
    }
};

struct Environment {
    bool pairing=false,connecting=false,pinVisible=false;
    uint16_t pairingSeconds=0;
    uint32_t pin=0;
};

class Animator {
public:
    void render(Frame& f,const Snapshot& s,const Environment& env,uint32_t now) {
        update(s,now);
        f.clear();
        if (env.pinVisible) { drawPin(f,env.pin,now); return; }
        header(f,s,env,now);
        recentText(f,s,now);
        trackPad(f,now);
        mouse(f,s,now);
    }
private:
    float x_=33.0f,y_=46.0f,targetX_=33.0f,targetY_=46.0f;
    float swayX_=0,swayY_=0,targetSwayX_=0,targetSwayY_=0;
    uint32_t lastFrame_=0,lastMotion_=0,lastWheel_=0,clickAt_=0;
    uint32_t flash_[8]{};
    int wheelDirection_=0,panDirection_=0,clickX_=0,clickY_=0;
    uint8_t trailCount_=0;
    int16_t trailX_[12]{},trailY_[12]{};
    bool haveFrame_=false,haveMotion_=false,haveWheel_=false,haveClick_=false;
    static float clampFloat(float value,float lo,float hi) { return value<lo ? lo : value>hi ? hi : value; }
    static int rounded(float v) { return int(v+(v>=0 ? 0.5f : -0.5f)); }
    void update(const Snapshot& s,uint32_t now) {
        const uint32_t dt=haveFrame_ ? uint32_t(now-lastFrame_) : 40;
        lastFrame_=now; haveFrame_=true;
        if (s.dx || s.dy) {
            targetX_=clampFloat(targetX_+float(s.dx)*0.14f,7,68);
            targetY_=clampFloat(targetY_+float(s.dy)*0.10f,37,53);
            targetSwayX_=clampFloat(float(s.dx)*0.05f,-2.5f,2.5f);
            targetSwayY_=clampFloat(float(s.dy)*0.04f,-1.5f,1.5f);
            lastMotion_=now; haveMotion_=true;
        } else { targetSwayX_*=0.77f; targetSwayY_*=0.77f; }
        const float ease=clampFloat(float(dt)/100.0f,0.08f,1.0f);
        x_+=(targetX_-x_)*ease; y_+=(targetY_-y_)*ease;
        swayX_+=(targetSwayX_-swayX_)*ease; swayY_+=(targetSwayY_-swayY_)*ease;
        if (haveMotion_ && uint32_t(now-lastMotion_)<650) {
            const int x=rounded(x_),y=rounded(y_);
            if (!trailCount_ || trailX_[0]!=x || trailY_[0]!=y) {
                for (int i=11;i>0;--i) { trailX_[i]=trailX_[i-1]; trailY_[i]=trailY_[i-1]; }
                trailX_[0]=int16_t(x); trailY_[0]=int16_t(y);
                if (trailCount_<12) ++trailCount_;
            }
        } else trailCount_=0;
        for (unsigned i=0;i<8;++i) if (s.clicks & (1u<<i)) flash_[i]=now+180;
        if (s.clicks) { clickAt_=now; clickX_=rounded(x_)+2; clickY_=rounded(y_)+3; haveClick_=true; }
        if (s.wheel || s.pan) {
            wheelDirection_=s.wheel>0 ? 1 : s.wheel<0 ? -1 : 0;
            panDirection_=s.pan>0 ? 1 : s.pan<0 ? -1 : 0;
            lastWheel_=now; haveWheel_=true;
        }
    }
    static void statusLight(Frame& f,int x,bool up,uint32_t now,bool blink=false) {
        if (up || (blink && ((now/220)&1))) f.box(x,3,3,3);
        else f.rect(x,3,3,3);
    }
    static void header(Frame& f,const Snapshot& s,const Environment& e,uint32_t now) {
        f.text(1,1,"K"); statusLight(f,9,s.keyboardUp,now,e.pairing);
        f.text(18,1,"M"); statusLight(f,26,s.mouseUp,now,e.pairing);
        f.text(35,1,"USB"); statusLight(f,55,s.usbUp,now);
        if (e.connecting) f.text(68,1,"LINK");
        else if (e.pairing) {
            char buffer[8]; snprintf(buffer,sizeof(buffer),"P%03u",unsigned(e.pairingSeconds));
            f.text(68,1,buffer);
        } else if (s.hidden) f.text(68,1,"HIDE");
        else if (s.caps) f.text(68,1,"CAPS");
        f.text(114,1,s.russian ? "RU" : "EN");
        f.line(0,11,127,11);
        if (e.pairing) f.line(0,10,clampInt(int(e.pairingSeconds)*127/120,0,127),10);
    }
    static void recentText(Frame& f,const Snapshot& s,uint32_t now) {
        f.roundRect(0,15,128,16);
        const char* notice=nullptr;
        if (deadlineActive(now,s.noticeUntil)) {
            switch (s.notice) {
            case Notice::English: notice="SCREEN: EN"; break;
            case Notice::Russian: notice="SCREEN: RU"; break;
            case Notice::Hidden: notice="TEXT HIDDEN"; break;
            case Notice::Visible: notice="TEXT VISIBLE"; break;
            case Notice::Cleared: notice="TEXT CLEARED"; break;
            default: break;
            }
        }
        if (notice) { f.text((128-int(strlen(notice))*6)/2,19,notice); return; }
        if (s.hidden) { f.text(16,19,"TEXT HIDDEN"); f.glyph(109,19,0x2022); return; }
        if (!s.length) {
            f.text(5,19,s.keyboardUp ? "TYPE SOMETHING..." : "WAITING FOR KEYS");
            return;
        }
        const int start=s.length>VisibleChars ? int(s.length-VisibleChars) : 0;
        int x=5;
        for (int i=start;i<s.length;++i,x+=6) f.glyph(x,19,s.text[i]);
        if ((now/500)%2==0) f.line(x,19,x,26);
    }
    static void pointer(Frame& f,int x,int y,bool outlineOnly=false) {
        // Tiny arrow; black interior keeps it distinct from the trail/grid.
        if (!outlineOnly) {
            for (int yy=0;yy<7;++yy) f.line(x,y+yy,x+yy/2,y+yy,false);
        }
        f.line(x,y,x,y+7); f.line(x,y,x+5,y+5); f.line(x+5,y+5,x+2,y+5);
        f.line(x,y+7,x+2,y+5); f.line(x+2,y+6,x+3,y+8);
    }
    void trackPad(Frame& f,uint32_t now) const {
        // Corner brackets and a sparse grid: enough texture without a solid panel.
        f.line(0,35,0,39); f.line(0,35,4,35);
        f.line(79,35,79,39); f.line(75,35,79,35);
        f.line(0,59,0,63); f.line(0,63,4,63);
        f.line(79,59,79,63); f.line(75,63,79,63);
        for (int yy=39;yy<62;yy+=8) for (int xx=7;xx<76;xx+=10) f.pixel(xx,yy);
        const uint32_t age=haveMotion_ ? uint32_t(now-lastMotion_) : 1000;
        for (int i=int(trailCount_)-1;i>=1;--i) {
            if (age>400 && (i&1)) continue;
            f.pixel(trailX_[i]+1,trailY_[i]+2);
            if (i<4 && age<350) f.pixel(trailX_[i]+2,trailY_[i]+3);
        }
        if (haveClick_ && uint32_t(now-clickAt_)<400) {
            const int radius=3+int(uint32_t(now-clickAt_)/50);
            // Clip the ripple to the track area by drawing in a temporary bounds check.
            for (int yy=35;yy<=62;++yy) for (int xx=1;xx<=78;++xx) {
                const int dx=xx-clickX_,dy=yy-clickY_,r2=dx*dx+dy*dy;
                if (r2>=radius*radius-radius && r2<=radius*radius+radius) f.pixel(xx,yy);
            }
        }
        pointer(f,rounded(x_),rounded(y_));
    }
    void mouse(Frame& f,const Snapshot& s,uint32_t now) const {
        const int dx=rounded(swayX_),dy=rounded(swayY_);
        const int left=96+dx,top=35+dy;
        uint8_t lit=s.buttons;
        for (unsigned i=0;i<8;++i) if (deadlineActive(now,flash_[i])) lit|=uint8_t(1u<<i);
        // Cable stem, contour, separate buttons, wheel and a moving palm highlight.
        f.line(left+10,top-3,left+10,top);
        f.roundRect(left,top,21,27);
        f.line(left+1,top+12,left+19,top+12);
        f.line(left+10,top+1,left+10,top+3);
        f.line(left+10,top+10,left+10,top+12);
        if (lit&1) f.roundRect(left+2,top+2,6,9,true);
        if (lit&2) f.roundRect(left+13,top+2,6,9,true);
        f.roundRect(left+8,top+4,5,6,(lit&4)!=0);
        const bool scroll=haveWheel_ && uint32_t(now-lastWheel_)<450;
        if (scroll && !(lit&4)) {
            const int phase=int((now/60)%3);
            f.pixel(left+10,top+5+(wheelDirection_<0 ? 2-phase : phase));
        } else if (!(lit&4)) f.line(left+10,top+5,left+10,top+7);
        f.line(left+5,top+21,left+15,top+21);
        f.pixel(left+8,top+23); f.pixel(left+12,top+23);
        // Side buttons have their own small indicators.
        f.box(left-3,top+12,2,4,(lit&8)!=0); if (!(lit&8)) f.line(left-3,top+12,left-3,top+15);
        f.box(left-3,top+18,2,4,(lit&16)!=0); if (!(lit&16)) f.line(left-3,top+18,left-3,top+21);
        if (scroll && wheelDirection_) {
            const int x=123,y=wheelDirection_>0 ? 40 : 55;
            f.line(x,y,x,y+(wheelDirection_>0 ? 5 : -5));
            f.line(x,y,x-2,y+(wheelDirection_>0 ? 2 : -2));
            f.line(x,y,x+2,y+(wheelDirection_>0 ? 2 : -2));
        }
        if (scroll && panDirection_) {
            const int x=panDirection_>0 ? 124 : 88;
            f.line(x,48,x+(panDirection_>0 ? -4 : 4),48);
            f.pixel(x+(panDirection_>0 ? -1 : 1),47);
            f.pixel(x+(panDirection_>0 ? -1 : 1),49);
        }
        if (!s.mouseUp) {
            f.line(left+6,top+16,left+14,top+24);
            f.line(left+14,top+16,left+6,top+24);
        } else if (haveMotion_ && uint32_t(now-lastMotion_)<200) {
            f.line(left-7,top+5,left-5,top+5);
            f.line(left-8,top+8,left-5,top+8);
        }
    }
    static void drawPin(Frame& f,uint32_t pin,uint32_t now) {
        f.text(22,2,"PAIR KEYBOARD"); f.line(0,13,127,13);
        char digits[7]; snprintf(digits,sizeof(digits),"%06lu",static_cast<unsigned long>(pin%1000000));
        f.text(28,22,digits,2);
        f.text(7,43,"TYPE PIN + ENTER");
        f.text(10,55,"ONLY IF REQUESTED");
        f.pixel(3+int((now/150)%120),62);
    }
};
}} // namespace bridge::screen
