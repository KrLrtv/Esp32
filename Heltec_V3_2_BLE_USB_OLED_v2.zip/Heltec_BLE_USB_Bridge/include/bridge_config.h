#pragma once
// Heltec WiFi LoRa 32 V3.x (ESP32-S3), NOT Wireless Stick / V4.
#define BRIDGE_USE_OLED 1
#define BRIDGE_OLED_SDA 17
#define BRIDGE_OLED_SCL 18
#define BRIDGE_OLED_RESET 21
#define BRIDGE_VEXT_PIN 36
#define BRIDGE_BUTTON_PIN 0
#define BRIDGE_PAIRING_MS 120000UL
#define BRIDGE_MAX_INPUT_REPORTS 16
// Optional, case-sensitive advertised-name substring; empty = HID service filter.
#define BRIDGE_NAME_FILTER ""

// OLED dashboard: no font download and no persistent typing log.
#define BRIDGE_DISPLAY_FRAME_MS 40UL   // Target 25 FPS; actual rate depends on I2C/task load.
#define BRIDGE_DISPLAY_RUSSIAN 0       // 0 = US English; 1 = standard Russian, screen only.
#define BRIDGE_DISPLAY_CLEAR_MS 30000UL // Clear text after 30 s without a new key press; 0 = off.
#define BRIDGE_DISPLAY_CLICK_GAP_MS 350UL
