#pragma once
#include <array>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

// Portable OLED-only state. No BLE/USB calls, heap allocation, or persistent log.
// Callers serialize access; draw from a snapshot, never while holding a lock.
namespace bridge {
namespace screen {
using KeyBits = std::array<uint8_t,32>;
constexpr size_t TextCapacity=48;
constexpr size_t VisibleChars=19;
enum class Notice : uint8_t { None, English, Russian, Hidden, Visible, Cleared };

struct Snapshot {
    uint16_t text[TextCapacity]{};
    uint8_t length=0,buttons=0,clicks=0;
    bool russian=false,hidden=false,caps=false,num=true;
    bool keyboardUp=false,mouseUp=false,usbUp=false;
    int32_t dx=0,dy=0,wheel=0,pan=0;
    uint32_t lastInput=0,noticeUntil=0;
    Notice notice=Notice::None;
};
inline bool keyDown(const KeyBits& keys,unsigned key) {
    return key<256 && (keys[key>>3] & uint8_t(1u<<(key&7)));
}
inline bool deadlineActive(uint32_t now,uint32_t until) {
    return until!=0 && int32_t(until-now)>0;
}
inline int32_t boundedAdd(int32_t a,int32_t b) {
    const int64_t value=int64_t(a)+b;
    return value>1000000 ? 1000000 : value<-1000000 ? -1000000 : int32_t(value);
}

// HID physical key positions -> screen characters, NOT Windows text capture.
// EN=US QWERTY, RU=standard Russian. IME, dead keys and host layout are unknown.
inline uint16_t character(uint8_t key,bool shift,bool caps,bool russian,bool num) {
    static const uint16_t ruLetters[26]={
        0x0444,0x0438,0x0441,0x0432,0x0443,0x0430,0x043F,0x0440,0x0448,
        0x043E,0x043B,0x0434,0x044C,0x0442,0x0449,0x0437,0x0439,0x043A,
        0x044B,0x0435,0x0433,0x043C,0x0446,0x0447,0x043D,0x044F
    };
    const bool upper=shift!=caps;
    if (key>=4 && key<=29) {
        if (!russian) return uint16_t((upper ? 'A' : 'a')+key-4);
        const uint16_t c=ruLetters[key-4];
        return upper ? uint16_t(c-0x20) : c;
    }
    if (key>=30 && key<=39) {
        static const char plain[]="1234567890";
        static const char shifted[]="!@#$%^&*()";
        static const uint16_t ruShift[]={ '!','"',0x2116,';','%',':','?','*','(',')' };
        return shift ? (russian ? ruShift[key-30] : uint16_t(shifted[key-30]))
                     : uint16_t(plain[key-30]);
    }
    if (russian) {
        uint16_t letter=0;
        switch (key) {
        case 47: letter=0x0445; break; // [ -> х
        case 48: letter=0x044A; break; // ] -> ъ
        case 51: letter=0x0436; break; // ; -> ж
        case 52: letter=0x044D; break; // ' -> э
        case 53: return upper ? 0x0401 : 0x0451; // ё
        case 54: letter=0x0431; break; // , -> б
        case 55: letter=0x044E; break; // . -> ю
        case 56: return shift ? ',' : '.';
        default: break;
        }
        if (letter) return upper ? uint16_t(letter-0x20) : letter;
    }
    switch (key) {
    case 40: case 88: return 0x21B5; // Enter marker
    case 43: return 0x21E5; // Tab marker
    case 44: return ' ';
    case 45: return shift ? '_' : '-';
    case 46: return shift ? '+' : '=';
    case 47: return shift ? '{' : '[';
    case 48: return shift ? '}' : ']';
    case 49: case 100: return shift ? (russian ? '/' : '|') : '\\';
    case 50: return shift ? '~' : '#';
    case 51: return shift ? ':' : ';';
    case 52: return shift ? '"' : '\'';
    case 53: return shift ? '~' : '`';
    case 54: return shift ? '<' : ',';
    case 55: return shift ? '>' : '.';
    case 56: return shift ? '?' : '/';
    case 84: return '/'; case 85: return '*'; case 86: return '-'; case 87: return '+';
    case 99: return num ? (russian ? ',' : '.') : 0;
    case 103: return '=';
    default:
        if (num && key>=89 && key<=97) return uint16_t('1'+key-89);
        if (num && key==98) return '0';
        return 0;
    }
}

class Model {
public:
    explicit Model(bool russian=false,uint32_t clearAfterMs=30000) : clearAfter_(clearAfterMs) {
        state_.russian=russian;
    }
    void status(bool keyboard,bool mouse,bool usb) {
        state_.keyboardUp=keyboard; state_.mouseUp=mouse; state_.usbUp=usb;
    }
    void keyboard(const KeyBits& keys,uint8_t modifiers,bool rollover,uint32_t now) {
        if (rollover) return; // Do not manufacture release/press edges from an error report.
        bool pressed=false;
        for (unsigned k=4;k<256;++k) {
            if (k>=0xE0 && k<=0xE7) continue;
            if (!keyDown(keys,k) || keyDown(previous_,k)) continue;
            pressed=true;
            if (k==57) { state_.caps=!state_.caps; continue; }
            if (k==83) { state_.num=!state_.num; continue; }
            // Ctrl, Alt/AltGr or GUI shortcuts must not be mistaken for typed text.
            if (modifiers & 0xDD) continue;
            if (state_.hidden) continue;
            if (k==42) { // Backspace edits just the local tail, not a document.
                if (state_.length) state_.text[--state_.length]=0;
                continue;
            }
            const uint16_t cp=character(uint8_t(k),(modifiers&0x22)!=0,
                                        state_.caps,state_.russian,state_.num);
            if (cp) append(cp);
        }
        previous_=keys;
        if (pressed) { state_.lastInput=now; lastTyping_=now; hasTyping_=true; }
    }
    void mouse(int32_t dx,int32_t dy,int32_t wheel,int32_t pan,uint8_t buttons,uint32_t now) {
        state_.dx=boundedAdd(state_.dx,dx); state_.dy=boundedAdd(state_.dy,dy);
        state_.wheel=boundedAdd(state_.wheel,wheel); state_.pan=boundedAdd(state_.pan,pan);
        state_.clicks |= uint8_t(buttons & ~state_.buttons);
        if (dx || dy || wheel || pan || buttons!=state_.buttons) state_.lastInput=now;
        state_.buttons=buttons;
    }
    void releaseInputs() {
        previous_.fill(0); state_.buttons=state_.clicks=0;
        state_.dx=state_.dy=state_.wheel=state_.pan=0;
    }
    void toggleLanguage(uint32_t now) {
        state_.russian=!state_.russian;
        note(state_.russian ? Notice::Russian : Notice::English,now);
    }
    void togglePrivacy(uint32_t now) {
        state_.hidden=!state_.hidden; clearText();
        note(state_.hidden ? Notice::Hidden : Notice::Visible,now);
    }
    void clearText() {
        memset(state_.text,0,sizeof(state_.text)); state_.length=0; hasTyping_=false;
    }
    void clearWithNotice(uint32_t now) { clearText(); note(Notice::Cleared,now); }
    Snapshot snapshot(uint32_t now) {
        if (hasTyping_ && clearAfter_ && uint32_t(now-lastTyping_)>=clearAfter_) clearText();
        Snapshot copy=state_;
        state_.dx=state_.dy=state_.wheel=state_.pan=0; state_.clicks=0;
        return copy;
    }
private:
    Snapshot state_{};
    KeyBits previous_{};
    uint32_t clearAfter_,lastTyping_=0;
    bool hasTyping_=false;
    void note(Notice n,uint32_t now) { state_.notice=n; state_.noticeUntil=now+1300; }
    void append(uint16_t cp) {
        if (state_.length==TextCapacity) {
            memmove(state_.text,state_.text+1,(TextCapacity-1)*sizeof(uint16_t));
            --state_.length;
        }
        state_.text[state_.length++]=cp;
    }
};
} // namespace screen
} // namespace bridge
