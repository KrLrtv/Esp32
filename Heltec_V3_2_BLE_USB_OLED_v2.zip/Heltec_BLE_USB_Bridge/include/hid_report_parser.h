#pragma once
#include <array>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

// BLE 0x2A4D normally excludes the report ID. Obtain the ID from descriptor 0x2908.
namespace bridge {
struct DecodedReport {
    bool keyboard=false, buttonsPresent=false, consumerPresent=false, rollover=false;
    uint8_t modifiers=0, buttons=0;
    std::array<uint8_t,32> keys{};
    uint16_t consumer=0;
    int32_t x=0, y=0, wheel=0, pan=0;
};

class ReportMap {
public:
    static constexpr size_t MaxFields=384;
    static constexpr size_t MaxReports=16;
    static constexpr size_t MaxReportBytes=128;
    struct Report { uint8_t id=0; uint16_t bits=0; };

    bool parse(const uint8_t* data, size_t length) {
        fieldCount_=reportCount_=0; keyboard_=mouse_=false; error_=nullptr;
        if (!data || !length) return fail("empty report map");
        Global g{}; Global stack[8]{}; size_t depth=0; Local local{};
        for (size_t p=0; p<length;) {
            const uint8_t prefix=data[p++];
            if (prefix==0xfe) {
                if (p+2>length) return fail("truncated long item");
                const size_t n=data[p]; p+=2;
                if (n>length-p) return fail("truncated long payload");
                p+=n; continue;
            }
            const size_t n=(prefix&3)==3 ? 4 : (prefix&3);
            if (n>length-p) return fail("truncated short item");
            uint32_t value=0;
            for (size_t j=0;j<n;++j) value |= uint32_t(data[p+j])<<(8*j);
            p+=n;
            const uint8_t type=(prefix>>2)&3, tag=prefix>>4;
            if (type==1) {
                switch(tag) {
                case 0: g.page=value; break;
                case 1: g.logicalMin=signedValue(value,n*8); break;
                case 7: g.size=value; break;
                case 8:
                    if (!value || value>255) return fail("invalid report ID");
                    g.id=uint8_t(value); break;
                case 9: g.count=value; break;
                case 10:
                    if (depth==8) return fail("global stack overflow");
                    stack[depth++]=g; break;
                case 11:
                    if (!depth) return fail("unbalanced global pop");
                    g=stack[--depth]; break;
                default: break;
                }
            } else if (type==2) {
                if (tag==0) {
                    if (local.count==128) return fail("too many local usages");
                    local.usages[local.count++]=value;
                } else if (tag==1) { local.minimum=value; local.hasMinimum=true; }
                else if (tag==2) { local.maximum=value; local.hasMaximum=true; }
                else if (tag==10 && value) return fail("usage delimiters unsupported");
            } else if (type==0) {
                if (tag==8) {
                    if (!g.size || g.size>32 || !g.count || g.count>1024)
                        return fail("unsupported input width/count");
                    Report* r=findOrCreate(g.id);
                    if (!r) return fail("too many report IDs");
                    const uint32_t end=uint32_t(r->bits)+g.size*g.count;
                    if (end>MaxReportBytes*8) return fail("input report too long");
                    if (!(value&1)) {
                        if (value&2) {
                            for (uint32_t i=0;i<g.count;++i)
                                if (!append(g,uint16_t(r->bits+i*g.size),1,usageAt(local,i),
                                            true,(value&4)!=0)) return false;
                        } else {
                            const uint32_t u=local.hasMinimum ? local.minimum : 0;
                            if (!append(g,r->bits,uint16_t(g.count),u,false,(value&4)!=0))
                                return false;
                        }
                    }
                    r->bits=uint16_t(end);
                }
                // Output/Feature use separate bit offsets. Local state expires
                // after every Main item, including Collection/End Collection.
                local=Local{};
            }
        }
        return reportCount_!=0 || fail("no input reports");
    }

    bool decode(uint8_t id, const uint8_t* data, size_t length, DecodedReport& out) const {
        out=DecodedReport{};
        const size_t need=reportBytes(id);
        if (!data || !need) return false;
        // Some nonconforming devices retain the Report ID in the BLE value.
        // Strip it only when both the exact length and ID agree.
        if (id && length==need+1 && data[0]==id) { ++data; --length; }
        if (length<need) return false;
        for (size_t i=0;i<fieldCount_;++i) {
            const Field& f=fields_[i];
            if (f.id!=id) continue;
            if (f.page==7) out.keyboard=true;
            if (f.page==9) out.buttonsPresent=true;
            if (f.page==0x0c && f.usage!=0x238) out.consumerPresent=true;
            for (uint16_t j=0;j<f.count;++j) {
                const uint32_t raw=bits(data,uint32_t(f.offset)+uint32_t(j)*f.size,f.size);
                const int32_t v=f.signedInput ? signedValue(raw,f.size) : int32_t(raw);
                uint32_t u=f.usage;
                if (!f.variable) {
                    if (!raw) continue;
                    const int64_t selected=int64_t(v)-f.logicalMin+f.usage;
                    if (selected<0 || selected>65535) continue;
                    u=uint32_t(selected);
                } else if (!v && f.page!=1 && !(f.page==0x0c && f.usage==0x238)) continue;
                if (f.page==7) {
                    if (u>=0xe0 && u<=0xe7) out.modifiers |= uint8_t(1u<<(u-0xe0));
                    else if (u>=1 && u<=3) out.rollover=true;
                    else if (u>=4 && u<=255) out.keys[u>>3] |= uint8_t(1u<<(u&7));
                } else if (f.page==9 && u>=1 && u<=8) {
                    out.buttons |= uint8_t(1u<<(u-1));
                } else if (f.page==1 && f.relative) {
                    if (u==0x30) out.x=addSaturated(out.x,v);
                    else if (u==0x31) out.y=addSaturated(out.y,v);
                    else if (u==0x38) out.wheel=addSaturated(out.wheel,v);
                } else if (f.page==0x0c) {
                    if (u==0x238 && f.relative) out.pan=addSaturated(out.pan,v);
                    else if (u && u<=0x3ff && !out.consumer) out.consumer=uint16_t(u);
                }
            }
        }
        return true;
    }
    bool hasKeyboard() const { return keyboard_; }
    bool hasMouse() const { return mouse_; }
    size_t reportCount() const { return reportCount_; }
    uint8_t reportId(size_t i) const { return i<reportCount_ ? reports_[i].id : 0; }
    size_t reportBytes(uint8_t id) const {
        for (size_t i=0;i<reportCount_;++i)
            if (reports_[i].id==id) return (reports_[i].bits+7)/8;
        return 0;
    }
    const char* error() const { return error_ ? error_ : "OK"; }
private:
    struct Global { uint32_t page=0,size=0,count=0; int32_t logicalMin=0; uint8_t id=0; };
    struct Local {
        uint32_t usages[128]{}; size_t count=0;
        uint32_t minimum=0,maximum=0; bool hasMinimum=false,hasMaximum=false;
    };
    struct Field {
        uint16_t offset=0,page=0,usage=0,count=0; int32_t logicalMin=0;
        uint8_t id=0,size=0; bool variable=false,relative=false,signedInput=false;
    };
    std::array<Field,MaxFields> fields_{};
    std::array<Report,MaxReports> reports_{};
    size_t fieldCount_=0,reportCount_=0;
    bool keyboard_=false,mouse_=false;
    const char* error_=nullptr;
    bool fail(const char* message) { error_=message; return false; }
    Report* findOrCreate(uint8_t id) {
        for (size_t i=0;i<reportCount_;++i) if (reports_[i].id==id) return &reports_[i];
        if (reportCount_==MaxReports) return nullptr;
        reports_[reportCount_]=Report{}; reports_[reportCount_].id=id;
        return &reports_[reportCount_++];
    }
    static uint32_t usageAt(const Local& l,uint32_t i) {
        if (i<l.count) return l.usages[i];
        if (l.hasMinimum) {
            uint32_t u=l.minimum+(i-uint32_t(l.count));
            if (l.hasMaximum && u>l.maximum) u=l.maximum;
            return u;
        }
        return l.count ? l.usages[l.count-1] : 0;
    }
    bool append(const Global& g,uint16_t offset,uint16_t count,uint32_t usage,
                bool variable,bool relative) {
        const uint16_t page=uint16_t(usage>>16 ? usage>>16 : g.page);
        if (page!=7 && page!=9 && page!=1 && page!=0x0c) return true;
        if (fieldCount_==MaxFields) return fail("too many input fields");
        Field& f=fields_[fieldCount_++];
        f.offset=offset; f.page=page; f.usage=uint16_t(usage); f.count=count;
        f.logicalMin=g.logicalMin; f.id=g.id; f.size=uint8_t(g.size);
        f.variable=variable; f.relative=relative; f.signedInput=g.logicalMin<0;
        if (page==7) keyboard_=true;
        if (page==1 && relative && (f.usage==0x30 || f.usage==0x31)) mouse_=true;
        return true;
    }
    static uint32_t bits(const uint8_t* p,uint32_t offset,uint8_t count) {
        uint32_t v=0;
        for (uint8_t i=0;i<count;++i)
            if (p[(offset+i)>>3] & (1u<<((offset+i)&7))) v |= uint32_t(1)<<i;
        return v;
    }
    static int32_t signedValue(uint32_t v,size_t n) {
        if (!n) return 0;
        if (n>=32) return int32_t(v);
        const uint32_t sign=uint32_t(1)<<(n-1);
        return int32_t((v^sign)-sign);
    }
    static int32_t addSaturated(int32_t a,int32_t b) {
        const int64_t v=int64_t(a)+b;
        return v>INT32_MAX ? INT32_MAX : v<INT32_MIN ? INT32_MIN : int32_t(v);
    }
};
} // namespace bridge
